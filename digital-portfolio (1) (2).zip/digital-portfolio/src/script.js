[]

main.js

Run

1           l      men    yertpt

2

3

4 Th      utt-lsm  me

5 i  avascript

6

7

8   l    variasl=

9 let message="Hello,Javascript!";

10

11       8508e x the coE6le

12 console.log(message);

13

14        frtion

15 function greet(name){

16 return "Hello,"+name+"!";

17 }

18

19   al     u         ore the reul

20 let greeting=greet("World");

21

22   g the sreetirg

23 console.log(greeting);

24

25 Aed an ever lietever a a luttar tassurirs

a buttan wath id='ng³u te           HTAL)

26   ntlt        r

acdecer l   ener(         ict)

27        Etar cic<ee!",

28

Output

Hello,JavaScript!

Hello,World!

eee tode Execut:an ucxessful =e=